package com.example.whoisolder;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Juego extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);

        TextView name = findViewById(R.id.hola);
        Bundle bundle = getIntent().getExtras();
        String dato = bundle.getString("nombre");
        name.setText(dato);

    }
}